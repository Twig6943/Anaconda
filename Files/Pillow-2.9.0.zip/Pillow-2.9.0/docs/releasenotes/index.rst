Release Notes
=============

.. note:: Contributors please include release notes as needed or appropriate with your bug fixes, feature additions and tests.

.. toctree::
  :maxdepth: 2

  2.7.0
  2.8.0
